package com.engispace.model;

public class UserAccount {
    private String username;
    private String fullName;
    private String password;
    private String role;
    private boolean enabled = true;

    public UserAccount() {}

    public UserAccount(String username, String fullName, String password, String role, boolean enabled) {
        this.username = username;
        this.fullName = fullName;
        this.password = password;
        this.role = role;
        this.enabled = enabled;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
